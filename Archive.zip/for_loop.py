for x in range(0, 3):
    print "We're on time %d" % (x)

print "The End!"