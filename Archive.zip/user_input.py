#!/usr/bin/python
# Demonstrates getting user input
name = raw_input("Hi.  What's your name? ")
print name
print "Hi,", name
raw_input("\n\nPress the enter key to exit.")